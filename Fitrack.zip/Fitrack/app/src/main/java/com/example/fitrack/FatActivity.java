package com.example.fitrack;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class FatActivity extends AppCompatActivity {

    RadioButton radioMale, radioFemale;
    EditText editAge, editWeight, editHeight, editAbdomen, editHip, editNeck;
    Button btnCalculate, btnBack;
    TextView fatResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fat);

        radioMale = findViewById(R.id.radioMaleFat);
        radioFemale = findViewById(R.id.radioFemaleFat);
        editAge = findViewById(R.id.editAge);
        editWeight = findViewById(R.id.editWeightFat);
        editHeight = findViewById(R.id.editHeightFat);
        editAbdomen = findViewById(R.id.editAbdomen);
        editHip = findViewById(R.id.editHip);
        editNeck = findViewById(R.id.editNeck);
        btnCalculate = findViewById(R.id.btnCalculateFat);
        btnBack = findViewById(R.id.btnBackFat);
        fatResult = findViewById(R.id.fatResultText);

        btnBack.setOnClickListener(v -> {
            startActivity(new Intent(FatActivity.this, MainActivity.class));
            finish();
        });

        btnCalculate.setOnClickListener(v -> {
            try {
                double age = Double.parseDouble(editAge.getText().toString());
                double weight = Double.parseDouble(editWeight.getText().toString());
                double height = Double.parseDouble(editHeight.getText().toString());
                double abdomen = Double.parseDouble(editAbdomen.getText().toString());
                double hip = Double.parseDouble(editHip.getText().toString());
                double neck = Double.parseDouble(editNeck.getText().toString());

                double fatPercent;

                if (radioMale.isChecked()) {
                    // Simple estimation for males (U.S. Navy method)
                    fatPercent = 495 / (1.0324 - 0.19077 * Math.log10(abdomen - neck)
                            + 0.15456 * Math.log10(height)) - 450;
                } else if (radioFemale.isChecked()) {
                    // Simple estimation for females (U.S. Navy method)
                    fatPercent = 495 / (1.29579 - 0.35004 * Math.log10(abdomen + hip - neck)
                            + 0.22100 * Math.log10(height)) - 450;
                } else {
                    Toast.makeText(this, "Please select gender", Toast.LENGTH_SHORT).show();
                    return;
                }

                fatResult.setText(String.format("Estimated Body Fat: %.2f%%", fatPercent));
            } catch (Exception e) {
                Toast.makeText(this, "Please enter valid values", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
