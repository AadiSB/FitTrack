package com.example.fitrack;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class CalorieActivity extends AppCompatActivity {

    RadioButton radioMale, radioFemale;
    EditText editAge, editWeight, editHeight;
    Button btnCalculate, btnBack;
    TextView calorieResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calorie);

        // Bind UI elements
        radioMale = findViewById(R.id.radioMaleCal);
        radioFemale = findViewById(R.id.radioFemaleCal);
        editAge = findViewById(R.id.editAgeCal);
        editWeight = findViewById(R.id.editWeightCal);
        editHeight = findViewById(R.id.editHeightCal);
        btnCalculate = findViewById(R.id.btnCalculateCal);
        btnBack = findViewById(R.id.btnBackCal);
        calorieResult = findViewById(R.id.calorieResultText);

        btnBack.setOnClickListener(v -> {
            startActivity(new Intent(CalorieActivity.this, MainActivity.class));
            finish();
        });

        btnCalculate.setOnClickListener(v -> {
            try {
                int age = Integer.parseInt(editAge.getText().toString());
                double weight = Double.parseDouble(editWeight.getText().toString()); // in kg
                double height = Double.parseDouble(editHeight.getText().toString()); // in cm

                if (!radioMale.isChecked() && !radioFemale.isChecked()) {
                    Toast.makeText(this, "Please select gender", Toast.LENGTH_SHORT).show();
                    return;
                }

                // BMR calculation using Mifflin-St Jeor Equation
                double bmr;
                if (radioMale.isChecked()) {
                    bmr = 10 * weight + 6.25 * height - 5 * age + 5;
                } else {
                    bmr = 10 * weight + 6.25 * height - 5 * age - 161;
                }

                double maintain = bmr * 1.55; // moderate activity
                double gain = maintain + 500;
                double lose = maintain - 500;

                String result = String.format(
                        "Maintain Weight: %.0f kcal/day\nGain Weight: %.0f kcal/day\nLose Weight: %.0f kcal/day",
                        maintain, gain, lose);

                calorieResult.setText(result);

            } catch (Exception e) {
                Toast.makeText(this, "Please fill in valid values", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
