package com.example.fitrack;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    Button bmi, fat, calories, protein;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize buttons
        bmi= findViewById(R.id.bmi);
        fat = findViewById(R.id.fat);
        protein = findViewById(R.id.protein);
        calories = findViewById(R.id.calories);

        // Placeholder actions
        bmi.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, BMIActivity.class);
            startActivity(intent);
        });

        fat.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FatActivity.class);
            startActivity(intent);
        });


        protein.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ProteinActivity.class);
            startActivity(intent);
        });


        calories.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CalorieActivity.class);
            startActivity(intent);
        });

    }
}
