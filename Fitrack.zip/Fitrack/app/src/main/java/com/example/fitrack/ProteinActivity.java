package com.example.fitrack;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class ProteinActivity extends AppCompatActivity {

    Button btnBack, btnCalculate;
    RadioButton radioMale, radioFemale;
    EditText editWeight;
    RadioButton noExercise, lowTraining, activeTraining, sportsTraining;
    TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_protein);

        // Bind views
        btnBack = findViewById(R.id.btnBackProtein);
        btnCalculate = findViewById(R.id.btnCalculateProtein);
        radioMale = findViewById(R.id.radioMale);
        radioFemale = findViewById(R.id.radioFemale);
        editWeight = findViewById(R.id.editWeightProtein);
        noExercise = findViewById(R.id.radioNoExercise);
        lowTraining = findViewById(R.id.radioLowTraining);
        activeTraining = findViewById(R.id.radioActiveTraining);
        sportsTraining = findViewById(R.id.radioSportsTraining);
        resultText = findViewById(R.id.proteinResultText);

        btnBack.setOnClickListener(v -> {
            Intent intent = new Intent(ProteinActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });

        btnCalculate.setOnClickListener(v -> {
            String weightStr = editWeight.getText().toString();
            if (weightStr.isEmpty() || (!radioMale.isChecked() && !radioFemale.isChecked()) ||
                    (!noExercise.isChecked() && !lowTraining.isChecked() &&
                            !activeTraining.isChecked() && !sportsTraining.isChecked())) {
                Toast.makeText(this, "Please complete all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            double weight;
            try {
                weight = Double.parseDouble(weightStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid weight entered", Toast.LENGTH_SHORT).show();
                return;
            }

            double factor = 0;

            if (noExercise.isChecked()) factor = 0.8;
            else if (lowTraining.isChecked()) factor = 1.2;
            else if (activeTraining.isChecked()) factor = 1.5;
            else if (sportsTraining.isChecked()) factor = 1.8;

            double protein = weight * factor;

            resultText.setText(String.format("Recommended protein intake: %.1f grams/day", protein));
        });
    }
}
