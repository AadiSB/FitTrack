package com.example.fitrack;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class BMIActivity extends AppCompatActivity {

    EditText editHeight, editWeight;
    RadioButton radioImperial, radioStandard;
    Button btnCalculate, btnBack;
    TextView bmiResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi);

        // Bind views
        btnBack = findViewById(R.id.btnBack);
        editHeight = findViewById(R.id.editHeight);
        editWeight = findViewById(R.id.editWeight);
        radioImperial = findViewById(R.id.radioImperial);
        radioStandard = findViewById(R.id.radioStandard);
        btnCalculate = findViewById(R.id.btnCalculate);
        bmiResult = findViewById(R.id.textResult);

        // Back button functionality
        btnBack.setOnClickListener(v -> {
            Intent intent = new Intent(BMIActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });

        // Calculate BMI
        btnCalculate.setOnClickListener(v -> {
            String heightStr = editHeight.getText().toString();
            String weightStr = editWeight.getText().toString();

            if (heightStr.isEmpty() || weightStr.isEmpty()) {
                Toast.makeText(this, "Please enter both height and weight", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double height = Double.parseDouble(heightStr);
                double weight = Double.parseDouble(weightStr);
                double bmi;

                if (radioImperial.isChecked()) {
                    bmi = (weight * 703) / (height * height); // height in inches, weight in lbs
                } else {
                    bmi = weight / (height * height); // height in meters, weight in kg
                }

                bmiResult.setText(String.format("Your BMI is: %.2f", bmi));
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
